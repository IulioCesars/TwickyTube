
function mostrar_x()
{
	alert('data');
	//alert($_GET('video'));
}
